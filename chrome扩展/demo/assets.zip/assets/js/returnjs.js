/*
 * @Author: MWeiLiu 拦截页面脚本时，阻止页面脚本执行的注入脚本
 * @Date: 2019-01-16 17:28:55 
 * @Last Modified by: MWeiLiu
 * @Last Modified time: 2019-01-17 16:24:24
 */
console.log('哼哼!');